import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-cyan-400 flex flex-col items-center justify-center p-4">
      <div className="text-center">
        <h1 className="text-5xl md:text-7xl font-bold text-white drop-shadow-lg animate-pulse">
          Mil te amo, Mariela 💜💙
        </h1>
        <p className="mt-6 text-xl md:text-2xl text-white">
          Esta página está hecha solo para ti.
        </p>
      </div>
      <div className="mt-10 w-full max-w-md">
        <div className="aspect-w-16 aspect-h-9">
          <iframe
            className="w-full h-60 rounded-2xl shadow-lg"
            src="https://www.youtube.com/embed/pxxT7PzBfz8?autoplay=1&loop=1&playlist=pxxT7PzBfz8"
            title="Tus Vueltas - Milo J"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
      </div>
    </div>
  );
}
